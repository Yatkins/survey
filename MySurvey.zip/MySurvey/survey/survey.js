function showDiv() {
   document.getElementById('loader').style.display = "block";
}

if(document.getElementById('checkBtn')){
   document.getElementById('checkBtn').addEventListener('click', (e) => checkIfCheckboxesChecked(e))
}

const checkIfCheckboxesChecked = (e) => {
   const checkboxes = document.querySelectorAll('input[type=checkbox]');

   const empty = [].filter.call(checkboxes, (element) => !element.checked)

   if(checkboxes.length === empty.length) {
      e.preventDefault()
      alert('At least one checkbox must be checked') 
   }
}

if(document.getElementById('textArea')){
   CKEDITOR.replace('textArea');
}
